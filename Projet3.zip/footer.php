<p>
    <a href="">Mentions légales</a> | <a href="">Contact</a>
</p>