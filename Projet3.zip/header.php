    <a href="index.php"><img src="Images\LOGO_GBAF_ROUGE" alt="Logo GBAF" height="200" /></a>
    <p id="textheader">Nom & Prénom<br />
        <a href="disconnect.php">Déconnexion</a>
    </p>