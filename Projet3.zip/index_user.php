<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="/styles.css?version=1">
    <title>GBAF Intranet Index</title>
</head>

<body>
    <div id="main">
        <header>
            <?php include("header.php"); ?>
        </header>

        <section>
            <article id="cadrepresa">
                <center>
                    <h1>Groupement banque-assurance français</h1>
                    <p>texte présentation du GBAF et du site</p>
                    <img src="" />
                </center>
            </article>
            <article>
                <h2>H2</h2>
                <p>texte acteurs et partenaires</p>
            </article>
            <article>
                <img src="">
                <h3>Nom du partenaire</h3>
                <p>contenu textuel + lien</p>
                <button class="button">Lire la suite</button>
            </article>
            <article>
                <img src="">
                <h3>Nom du partenaire</h3>
                <p>contenu textuel + lien</p>
                <button class="button">Lire la suite</button>
            </article>
            <article>
                <img src="">
                <h3>Nom du partenaire</h3>
                <p>contenu textuel + lien</p>
                <button class="button">Lire la suite</button>
            </article>
            <article>
                <img src="">
                <h3>Nom du partenaire</h3>
                <p>contenu textuel + lien</p>
                <button class="button">Lire la suite</button>
            </article>
            <article>
                <img src="">
                <h3>Nom du partenaire</h3>
                <p>contenu textuel + lien</p>
                <button class="button">Lire la suite</button>
            </article>
            <article>
                <img src="">
                <h3>Nom du partenaire</h3>
                <p>contenu textuel + lien</p>
                <button class="button">Lire la suite</button>
            </article>
        </section>

        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </div>
</body>

</html>